﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryPlayer : MonoBehaviour
{
    //Huecos libres y objetos guardados
    public bool[] estaLleno = new bool[3];
    public GameObject[]objetos = new GameObject[3];

}
